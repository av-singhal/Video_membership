Run server
```
uvicorn app.main:app --reload
```